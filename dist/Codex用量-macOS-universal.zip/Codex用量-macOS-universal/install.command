#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_NAME="Codex 用量"
APP_SOURCE="$SCRIPT_DIR/$APP_NAME.app"
INSTALL_DIR="/Applications"
PLIST="$HOME/Library/LaunchAgents/com.local.codex-usage-menu.plist"
LOG_DIR="$HOME/Library/Logs"

if [[ ! -d "$APP_SOURCE" ]]; then
  echo "找不到 $APP_NAME.app，请确认 install.command 和 App 在同一个文件夹里。"
  exit 1
fi

if [[ ! -w "$INSTALL_DIR" ]]; then
  INSTALL_DIR="$HOME/Applications"
fi

mkdir -p "$INSTALL_DIR" "$HOME/Library/LaunchAgents" "$LOG_DIR"
APP_DEST="$INSTALL_DIR/$APP_NAME.app"
APP_BINARY="$APP_DEST/Contents/MacOS/codex-usage-menu"

launchctl bootout "gui/$(id -u)" "$PLIST" 2>/dev/null || true
pkill -x codex-usage-menu 2>/dev/null || true

rm -rf "$APP_DEST"
cp -R "$APP_SOURCE" "$APP_DEST"
xattr -dr com.apple.quarantine "$APP_DEST" 2>/dev/null || true
xattr -dr com.apple.provenance "$APP_DEST" 2>/dev/null || true

cat > "$PLIST" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.local.codex-usage-menu</string>
  <key>ProgramArguments</key>
  <array>
    <string>$APP_BINARY</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>StandardOutPath</key>
  <string>$LOG_DIR/codex-usage-menu.log</string>
  <key>StandardErrorPath</key>
  <string>$LOG_DIR/codex-usage-menu.err.log</string>
</dict>
</plist>
PLIST

launchctl bootstrap "gui/$(id -u)" "$PLIST"
launchctl kickstart -k "gui/$(id -u)/com.local.codex-usage-menu"
open -R "$APP_DEST"

echo
echo "安装完成：$APP_DEST"
echo "已设置登录后自动启动。$APP_NAME 是菜单栏 App，没有普通窗口。"
echo "如果菜单栏没有立刻出现，请双击打开 $APP_NAME.app。"
echo "如果 macOS 阻止打开，请右键 $APP_NAME.app，选择“打开”。"
