Codex 用量 - macOS 安装说明

1. 双击 install.command 安装。
2. 如果 macOS 阻止打开，请右键 install.command，选择“打开”。
3. 安装后会出现在 /Applications/Codex 用量.app。
4. 它是菜单栏 App，打开后没有普通窗口，请看屏幕顶部菜单栏。
5. 需要这台 Mac 上已经使用过 Codex，并存在 ~/.codex/sessions 记录，才会显示真实用量。
6. 当前发布包是 universal 版本，适用于 Apple Silicon 和 Intel Mac。
