Codex 用量 - macOS 安装说明

包内文件：
- Codex 用量.app：菜单栏 App 本体。
- install.command：一键安装脚本，会复制 App 并设置登录后自动启动。
- Applications：手动拖拽安装用的快捷入口。

快速安装：
1. 双击 install.command 安装并设置开机自启。
2. 安装完成后看屏幕顶部菜单栏；这个 App 没有普通窗口。
3. 如果 macOS 阻止打开，请右键 install.command，选择“打开”。

手动安装：
1. 把“Codex 用量.app”拖到 Applications 文件夹。
2. 双击打开 App。

说明：
- App 名称和图标与 iOS 版本一致。
- 它是菜单栏 App，打开后没有普通窗口，请看屏幕顶部菜单栏。
- macOS 版本内置独立的 Mac 桌面小组件，可在系统“小组件”里添加“Codex 用量”。
- 优先通过本机 Codex 接口读取实时用量，失败时才回退读取本地记录。
- 这个 App 没有上架和 notarize。如果 macOS 阻止打开，请右键 install.command 或 App，选择“打开”。
- 当前发布包是 universal 版本，适用于 Apple Silicon 和 Intel Mac。
- 登录启动通过 macOS LaunchServices 完成，兼容 macOS 26.6 及更新版本。
